const card = document.querySelector(".card__inner");

card.addEventListener('mouseover', () => {
  card.classList.add('is-flipped');
});

card.addEventListener('mouseout', () => {
  card.classList.remove('is-flipped');
});

const card2 = document.querySelector(".card__inner2");

card2.addEventListener('mouseover', () => {
  card2.classList.add('is-flipped');
});

card2.addEventListener('mouseout', () => {
  card2.classList.remove('is-flipped');
});


const card3 = document.querySelector(".card__inner3");

card3.addEventListener('mouseover', () => {
  card3.classList.add('is-flipped');
});

card3.addEventListener('mouseout', () => {
  card3.classList.remove('is-flipped');
});


const card4 = document.querySelector(".card__inner4");

card4.addEventListener('mouseover', () => {
  card4.classList.add('is-flipped');
});

card4.addEventListener('mouseout', () => {
  card4.classList.remove('is-flipped');
});